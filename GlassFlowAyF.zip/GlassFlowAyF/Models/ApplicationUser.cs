﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace GlassFlowAyF.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [StringLength(120)]
        public string NombreCompleto { get; set; }
            = string.Empty;


        [StringLength(300)]
        public string? Direccion { get; set; }


        public DateTime FechaRegistro { get; set; }
            = DateTime.Now;


        public bool Activo { get; set; } = true;


        public ICollection<TrabajoInstalacion>
            TrabajosAsignados
        { get; set; }
            = new List<TrabajoInstalacion>();


        public ICollection<Compra>
            Compras
        { get; set; }
            = new List<Compra>();


        // ============================================
        // SOPORTE
        // ============================================

        public ICollection<SoporteSolicitud>
            SolicitudesSoporte
        { get; set; }
            = new List<SoporteSolicitud>();
    }
}