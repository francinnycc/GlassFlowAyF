﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GlassFlowAyF.Models
{
    public class SolicitudCotizacion
    {
        public ICollection<ValidacionTecnica> ValidacionesTecnicas { get; set; } = new List<ValidacionTecnica>();
        public int Id { get; set; }

        [Required]
        [StringLength(120)]
        [Display(Name = "Nombre del cliente")]
        public string NombreCliente { get; set; }
            = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(150)]
        public string Correo { get; set; }
            = string.Empty;

        [Required]
        [Phone]
        [StringLength(30)]
        public string Telefono { get; set; }
            = string.Empty;


        // PRODUCTO

        [Display(Name = "Producto")]
        public int? ProductoId { get; set; }

        public Producto? Producto { get; set; }

        // Se conserva para solicitudes antiguas.
        [StringLength(120)]
        [Display(Name = "Producto solicitado")]
        public string TipoProducto { get; set; }
            = string.Empty;


        // MATERIAL

        [Display(Name = "Material y acabado")]
        public int? MaterialId { get; set; }

        public Material? Material { get; set; }


        // DESCRIPCIÓN

        [Required(
            ErrorMessage =
                "Describa el trabajo que necesita.")]
        [StringLength(1000)]
        [Display(Name = "Descripción del trabajo")]
        public string Descripcion { get; set; }
            = string.Empty;


        // MEDIDAS

        [Column(TypeName = "decimal(10,2)")]
        [Range(0.01, 10000, ErrorMessage = "El ancho debe ser mayor que cero.")]
        [Display(Name = "Ancho aproximado (metros)")]
        public decimal? Ancho { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        [Range(0.01, 10000, ErrorMessage = "El alto debe ser mayor que cero.")]
        [Display(Name = "Alto aproximado (metros)")]
        public decimal? Alto { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        [Range(0.01, 10000, ErrorMessage = "La profundidad debe ser mayor que cero.")]
        [Display(Name = "Profundidad (metros)")]
        public decimal? Profundidad { get; set; }

        [Range(1, 100, ErrorMessage = "La cantidad debe estar entre 1 y 100.")]
        [Display(Name = "Cantidad")]
        public int Cantidad { get; set; } = 1;

        [Required(ErrorMessage = "Debe seleccionar una unidad de medida.")]
        [StringLength(2)]
        [Display(Name = "Unidad de medida")]
        public string UnidadMedida { get; set; } = "m";

        [Required(ErrorMessage = "Debe seleccionar el área de instalación.")]
        [StringLength(100)]
        [Display(Name = "Área de instalación")]
        public string UbicacionInstalacion { get; set; } = string.Empty;

        [StringLength(100)]
        [Display(Name = "Especifique la ubicación")]
        public string? UbicacionPersonalizada { get; set; }



        // INSTALACIÓN

        [Display(Name = "¿Requiere instalación?")]
        public bool RequiereInstalacion { get; set; }

        [StringLength(300)]
        public string? Direccion { get; set; }


        // INFORMACIÓN ADICIONAL

        [StringLength(500)]
        public string? Observaciones { get; set; }

        [StringLength(40)]
        public string Estado { get; set; }
            = "Solicitado";

        [Display(Name = "Fecha de solicitud")]
        public DateTime FechaSolicitud { get; set; }
            = DateTime.Now;

        [Column(TypeName = "decimal(12,2)")]
        [Display(Name = "Cotización estimada")]
        public decimal? MontoEstimado { get; set; }


        // FOTOGRAFÍAS

        public ICollection<SolicitudFotografia>
            Fotografias
        { get; set; }
                = new List<SolicitudFotografia>();


        // COTIZACIONES

        public ICollection<Cotizacion>
            Cotizaciones
        { get; set; }
                = new List<Cotizacion>();


        // DISEÑOS IA

        public ICollection<DisenoIA>
            DisenosIA
        { get; set; }
                = new List<DisenoIA>();
    }
}
